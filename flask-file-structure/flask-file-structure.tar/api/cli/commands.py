from ..common import db, home_api


@home_api.cli.command('db_init')
def db_init():
    print('database created')

@home_api.cli.command('db_drop')
def db_drop():
    print('database dropped')
