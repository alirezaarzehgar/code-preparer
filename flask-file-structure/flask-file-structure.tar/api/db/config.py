from ..common import home_api
import os

dbname = 'test.db'
basedir = os.path.abspath(os.path.dirname(__file__))

home_api.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, dbname)
