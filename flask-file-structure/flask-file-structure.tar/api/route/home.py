from ..common import home_api, jsonify


@home_api.route('/api')
def api():
    return jsonify('hello world')

