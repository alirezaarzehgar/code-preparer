from flask import Flask, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_marshmallow import Marshmallow


home_api = Flask(__name__)
db = SQLAlchemy(home_api)
ma = Marshmallow(home_api)
