from api.common import home_api
import api.route.home
import api.cli.commands
import api.db.config


if __name__ == '__main__':
    home_api.run()

